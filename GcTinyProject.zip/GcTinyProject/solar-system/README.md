# 2D Solar System Simulation

## Objective
This is a comprehensive Computer Graphics practical project that visually simulates a 2D representation of our Solar System. The project has been upgraded to demonstrate a full suite of geometric transformations, object interaction, interactive camera controls, and nested coordinate systems in a C environment using Raylib.

## Technologies
- Language: **C**
- Graphics Library: **Raylib**
- Math library: `<math.h>`

## 10 Core Features Implemented
1. **Zoom / Scaling:** Scale the entire simulation in and out using `[` and `]` without breaking orbital paths.
2. **Pan / Translation:** Move the camera across the world using Arrow keys to inspect different areas of the solar system.
3. **Planet Self-Rotation:** Planets independently rotate on their own axes (visualized by a marker line on each planet). Toggle with `L`.
4. **Coordinate Grid:** A toggleable Cartesian grid (`G`) demonstrating the underlying world coordinate system.
5. **Transformation Mode:** A dedicated mode (`T`) to interactively scale, translate, rotate, shear, and reflect selected planets without disrupting their orbital simulation.
6. **Asteroid Belt:** 250 randomized asteroids circling between Mars and Jupiter with varying sizes and speeds. Toggle with `B`.
7. **Comet:** An animated comet moving along a highly elliptical path with a fading tail. Toggle with `K`.
8. **Information Panel:** Displays detailed data about the currently selected planet. Toggle with `I`.
9. **Elliptical Orbits:** Switch between perfectly circular (`O`) and realistic elliptical (`E`) planetary orbits.
10. **Refined UI & Controls:** Clean graphical overlay displaying simulation status, live data, and available keyboard commands.

## Computer Graphics Concepts Demonstrated

- **Translation:** Used by camera panning. The camera offsets `(cameraX, cameraY)` are added to world coordinates to shift the view.
- **Scaling:** Used by the zoom system. World coordinates are multiplied by the `zoom` factor relative to the center of the screen.
- **Rotation:** Used by planet self-rotation and Transformation Mode.
- **Coordinate Systems (World-to-Screen):** Objects exist in fixed "World" coordinates. The `worldToScreen()` pipeline dynamically converts them into "Screen" coordinates using scaling and translation.
- **Elliptical Motion:** Demonstrated by the `E` mode and the Comet. Computed using `x = a * cos(t)` and `y = b * sin(t)`.
- **Randomization:** Used to dynamically generate the starfield and asteroid belt with varied speeds, sizes, and opacities on startup.
- **Hierarchical (Nested) Transformation:** Used by Earth and the Moon. The Moon's position is computed relative to Earth's moving coordinates, meaning it inherits Earth's translation.
- **Geometric Transformations (Affine):** Demonstrated through Transformation Mode, explicitly applying matrix-equivalent math (Scale, Reflect, Shear, Rotate, Translate) to polygon vertices.
- **Animation:** Used throughout the simulation via a continuous game loop updating position angles over time.
- **Object Selection:** Allows picking individual objects via number keys (1-9) to query data or apply transformations.

## Transformation Mathematics
The project manually calculates transformations before rendering using these geometric equivalents:
- **Translation:** `x' = x + Tx`, `y' = y + Ty`
- **Scaling:** `x' = x * Sx`, `y' = y * Sy`
- **Rotation:** `x' = x * cos(θ) - y * sin(θ)`, `y' = x * sin(θ) + y * cos(θ)`
- **Reflection:** Inverted scale multiplier (e.g., `x * -1`)
- **Shearing:** `x' = x + ShX * y`, `y' = y + ShY * x`
- **Elliptical Orbit:** `x = cx + radiusX * cos(θ)`, `y = cy + radiusY * sin(θ)`

---

## Setup and Execution (macOS)

Because traditional legacy `graphics.h` is incompatible with macOS, this project is built cleanly with **Raylib**. 

### 1. Install Dependencies
You need to have `Homebrew` installed. Then install `raylib` via terminal:
```bash
brew install raylib
```

### 2. Compilation Command
Navigate to the `solar-system` directory and compile the code:
```bash
clang -Wall main.c -I$(brew --prefix)/include -L$(brew --prefix)/lib -lraylib -o solarSystem
```

### 3. Execution Command
Run the compiled executable:
```bash
./solarSystem
```

---

## VIVA QUESTIONS (25 Questions)

**1. What is Computer Graphics?**
The creation, manipulation, and rendering of visual images and animations using computers.

**2. What is Translation in CG?**
Moving an object along the X or Y axis without changing its shape or size.

**3. Where is Translation used in your project?**
It is used in camera panning (moving the view) and when moving objects in Transformation Mode.

**4. What is Scaling?**
Changing the size of an object or the entire scene (zooming).

**5. How does your Zoom feature work?**
It multiplies the distance between an object's world coordinate and the screen center by a `zoom` factor.

**6. What is Rotation?**
Turning an object around a specific pivot point by a given angle.

**7. Why do you use `sin()` and `cos()`?**
To convert polar coordinates (radius and angle) into Cartesian coordinates (X and Y) to calculate circular and elliptical motion.

**8. What is the formula for a circular orbit?**
`x = centerX + radius * cos(angle)` and `y = centerY + radius * sin(angle)`.

**9. What is the difference between Circular and Elliptical orbits?**
A circular orbit uses a single radius. An elliptical orbit uses two distinct radii (`radiusX` and `radiusY`).

**10. How is Shearing demonstrated?**
In Transformation mode, shearing skews the shape of the selected planet along the X or Y axis by adding a multiple of the other axis to it.

**11. What is Hierarchical Transformation?**
When an object's transformation depends on another object. For example, the Moon revolves around the Earth, which in turn revolves around the Sun.

**12. Why don't the stars move when the planets do?**
The stars are drawn with static world coordinates. They only move relative to the screen if the user pans the camera.

**13. What is the difference between World Coordinates and Screen Coordinates?**
World coordinates are the actual, unchangeable positions in the simulation. Screen coordinates are where they are drawn on your monitor after applying camera pan and zoom.

**14. What causes animation in your project?**
A continuous `while` loop that clears the screen, increments orbital angles slightly, and redraws the objects every frame.

**15. How do you prevent screen flickering?**
By utilizing double buffering, where the next frame is drawn in memory and then swapped to the screen all at once (handled automatically by Raylib).

**16. What does `math.h` provide?**
Functions like `cosf()`, `sinf()`, and the constant `PI` for geometry calculations.

**17. What is Reflection in transformations?**
Flipping an object across an axis, achieved mathematically by multiplying the X or Y coordinate by -1.

**18. Why use an array of structures?**
To keep the code clean. We can loop through the `planets[]` array to update and draw all 8 planets without duplicating code.

**19. How did you create the Comet's tail?**
By drawing multiple faint, shrinking circles at positions calculated from slightly older angles behind the comet's current position.

**20. What is a Bounding Box?**
A rectangle drawn around an object (shown in yellow in Transformation Mode) to indicate it is currently selected.

**21. Why generate Asteroid positions only once?**
Because if we regenerated them every frame using `GetRandomValue()`, they would rapidly jump around and flicker instead of moving smoothly.

**22. How does Pause work?**
A `paused` boolean stops the simulation angles from incrementing, but the loop continues drawing, allowing the user to zoom and pan while paused.

**23. What is an Affine Transformation?**
A geometric transformation that preserves lines and parallelism (like translation, scaling, rotation, and shearing).

**24. Why draw the planets as polygons in Transformation mode?**
Standard circle functions cannot be sheared. By generating circle vertices manually and drawing them as polygons, we can mathematically apply shear and scale to every vertex.

**25. How do you exit Transformation mode without breaking the main simulation?**
The Transformation mode uses a separate `ObjectTransform` matrix for the selected object that only affects how it is drawn, without altering its actual world `orbitAngle` or `radius` variables.

## Troubleshooting

- **"raylib.h file not found"**: Ensure Raylib is installed via Homebrew and you compiled using the provided `$(brew --prefix)` command.
- **Simulation too fast/slow**: Use the `+` or `-` keys to adjust simulation speed manually.
- **Lost in space**: Press `C` to reset the camera and `0` to reset the zoom.
