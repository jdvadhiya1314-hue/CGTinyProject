#include <raylib.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define MAX_STARS 200
#define NUM_PLANETS 8

// Screen dimensions
const int screenWidth = 1200;
const int screenHeight = 800;

// Planet structure
typedef struct {
    char name[20];
    float orbitRadius;
    float radius;
    float angle;
    float baseSpeed;
    Color color;
} Planet;

// Star structure for the background
typedef struct {
    float x;
    float y;
    float radius;
    float alpha;
} Star;

Star stars[MAX_STARS];
Planet planets[NUM_PLANETS];

float simulationSpeed = 1.0f;
bool paused = false;
bool showOrbits = true;
bool showInfo = false;

// Initialize planets with relative sizes, colors and speeds
void initializePlanets() {
    // Mercury
    Planet p0 = {"Mercury", 80, 5, 0.0f, 0.040f, GRAY};
    planets[0] = p0;

    // Venus
    Planet p1 = {"Venus", 120, 7, 0.0f, 0.030f, (Color){ 255, 255, 150, 255 }}; // Light yellow
    planets[1] = p1;

    // Earth
    Planet p2 = {"Earth", 165, 8, 0.0f, 0.025f, (Color){ 50, 150, 255, 255 }}; // Blue/Green
    planets[2] = p2;

    // Mars
    Planet p3 = {"Mars", 210, 6, 0.0f, 0.020f, RED};
    planets[3] = p3;

    // Jupiter
    Planet p4 = {"Jupiter", 270, 16, 0.0f, 0.012f, ORANGE};
    planets[4] = p4;

    // Saturn
    Planet p5 = {"Saturn", 340, 14, 0.0f, 0.009f, (Color){ 230, 230, 150, 255 }}; // Pale yellow
    planets[5] = p5;

    // Uranus
    Planet p6 = {"Uranus", 410, 11, 0.0f, 0.006f, SKYBLUE};
    planets[6] = p6;

    // Neptune
    Planet p7 = {"Neptune", 480, 10, 0.0f, 0.004f, BLUE};
    planets[7] = p7;
}

// Generate a random star field
void initializeStars() {
    for (int i = 0; i < MAX_STARS; i++) {
        stars[i].x = (float)(GetRandomValue(0, screenWidth));
        stars[i].y = (float)(GetRandomValue(0, screenHeight));
        stars[i].radius = (float)(GetRandomValue(1, 2));
        stars[i].alpha = (float)(GetRandomValue(100, 255)) / 255.0f;
    }
}

// Reset the simulation angles and speed
void resetSimulation() {
    for (int i = 0; i < NUM_PLANETS; i++) {
        planets[i].angle = 0.0f;
    }
    simulationSpeed = 1.0f;
}

// Handle all user keyboard inputs
void handleInput() {
    if (IsKeyPressed(KEY_SPACE)) {
        paused = !paused;
    }
    if (IsKeyPressed(KEY_EQUAL) || IsKeyPressed(KEY_KP_ADD)) { 
        simulationSpeed += 0.5f;
    }
    if (IsKeyPressed(KEY_MINUS) || IsKeyPressed(KEY_KP_SUBTRACT)) {
        simulationSpeed -= 0.5f;
        if (simulationSpeed < 0.0f) simulationSpeed = 0.0f;
    }
    if (IsKeyPressed(KEY_R)) {
        resetSimulation();
    }
    if (IsKeyPressed(KEY_M)) {
        showOrbits = !showOrbits;
    }
    if (IsKeyPressed(KEY_I)) {
        showInfo = !showInfo;
    }
}

// Update the position angles of each planet
void updatePlanets() {
    for (int i = 0; i < NUM_PLANETS; i++) {
        planets[i].angle += planets[i].baseSpeed * simulationSpeed;
        if (planets[i].angle > 2 * PI) {
            planets[i].angle -= 2 * PI;
        }
    }
}

// Draw the stationary star background
void drawStars() {
    for (int i = 0; i < MAX_STARS; i++) {
        Color starColor = WHITE;
        starColor.a = (unsigned char)(stars[i].alpha * 255);
        DrawCircleV((Vector2){stars[i].x, stars[i].y}, stars[i].radius, starColor);
    }
}

// Draw the central Sun with a small glow effect
void drawSun(float centerX, float centerY) {
    DrawCircle(centerX, centerY, 55, (Color){ 255, 200, 0, 50 }); // Glow 1
    DrawCircle(centerX, centerY, 50, (Color){ 255, 200, 0, 100 });// Glow 2
    DrawCircle(centerX, centerY, 45, YELLOW);                     // Core
    DrawText("SUN", (int)centerX - 15, (int)centerY + 60, 10, YELLOW);
}

// Draw the informational panel about the planets
void drawInformationPanel() {
    int panelX = screenWidth - 320;
    int panelY = 60;
    int width = 300;
    int height = 240;
    
    // Draw semitransparent background
    DrawRectangle(panelX, panelY, width, height, (Color){ 0, 0, 0, 200 });
    DrawRectangleLines(panelX, panelY, width, height, WHITE);
    
    DrawText("SOLAR SYSTEM", panelX + 10, panelY + 10, 20, YELLOW);
    
    int yOffset = panelY + 40;
    int spacing = 20;
    
    DrawText("Sun      - Star at the center", panelX + 10, yOffset, 10, WHITE); yOffset += spacing;
    DrawText("Mercury  - Closest planet to Sun", panelX + 10, yOffset, 10, WHITE); yOffset += spacing;
    DrawText("Venus    - Second planet", panelX + 10, yOffset, 10, WHITE); yOffset += spacing;
    DrawText("Earth    - Our planet", panelX + 10, yOffset, 10, WHITE); yOffset += spacing;
    DrawText("Mars     - Red Planet", panelX + 10, yOffset, 10, WHITE); yOffset += spacing;
    DrawText("Jupiter  - Largest planet", panelX + 10, yOffset, 10, WHITE); yOffset += spacing;
    DrawText("Saturn   - Planet with prominent rings", panelX + 10, yOffset, 10, WHITE); yOffset += spacing;
    DrawText("Uranus   - Ice giant", panelX + 10, yOffset, 10, WHITE); yOffset += spacing;
    DrawText("Neptune  - Farthest major planet", panelX + 10, yOffset, 10, WHITE);
}

// Draw the top-left controls helper
void drawControls() {
    DrawText("SPACE - Pause / Resume", 10, 40, 10, RAYWHITE);
    DrawText("+     - Increase animation speed", 10, 55, 10, RAYWHITE);
    DrawText("-     - Decrease animation speed", 10, 70, 10, RAYWHITE);
    DrawText("R     - Reset simulation", 10, 85, 10, RAYWHITE);
    DrawText("M     - Toggle orbital paths", 10, 100, 10, RAYWHITE);
    DrawText("I     - Toggle information", 10, 115, 10, RAYWHITE);
    DrawText("ESC   - Exit", 10, 130, 10, RAYWHITE);
}

int main(void) {
    // Initialize Raylib window
    InitWindow(screenWidth, screenHeight, "2D SOLAR SYSTEM SIMULATION");
    SetTargetFPS(60);

    initializePlanets();
    initializeStars();

    float centerX = screenWidth / 2.0f;
    float centerY = screenHeight / 2.0f;

    // Animation Loop
    while (!WindowShouldClose()) {
        // 1. Handle Input
        handleInput();

        // 2. Update state
        if (!paused) {
            updatePlanets();
        }

        // 3. Draw
        BeginDrawing();
        ClearBackground(BLACK);

        drawStars();

        DrawText("2D SOLAR SYSTEM SIMULATION", screenWidth / 2 - MeasureText("2D SOLAR SYSTEM SIMULATION", 20) / 2, 10, 20, RAYWHITE);
        
        drawControls();

        // Draw Speed Display
        char speedText[50];
        sprintf(speedText, "Simulation Speed: %.1fx", simulationSpeed);
        DrawText(speedText, screenWidth - 200, 20, 15, RAYWHITE);
        if (paused) {
            DrawText("PAUSED", screenWidth - 100, 40, 15, RED);
        }

        drawSun(centerX, centerY);

        // Draw each planet, orbit, moon and rings
        for (int i = 0; i < NUM_PLANETS; i++) {
            // Draw Orbit paths
            if (showOrbits) {
                DrawCircleLines((int)centerX, (int)centerY, planets[i].orbitRadius, (Color){ 255, 255, 255, 50 });
            }

            // Calculate planet position using trigonometric functions
            // x = centerX + radius * cos(angle)
            // y = centerY + radius * sin(angle)
            float pX = centerX + planets[i].orbitRadius * cos(planets[i].angle);
            float pY = centerY + planets[i].orbitRadius * sin(planets[i].angle);

            // Draw Planet
            DrawCircle((int)pX, (int)pY, planets[i].radius, planets[i].color);

            // Draw Saturn's Rings
            if (i == 5) { // Saturn is index 5
                DrawEllipseLines((int)pX, (int)pY, planets[i].radius + 8, planets[i].radius + 2, (Color){ 200, 200, 200, 200 });
                DrawEllipseLines((int)pX, (int)pY, planets[i].radius + 10, planets[i].radius + 4, (Color){ 150, 150, 150, 150 });
            }

            // Draw Earth's Moon
            if (i == 2) { // Earth is index 2
                float moonOrbitRadius = 20.0f;
                float moonAngle = planets[i].angle * 4.0f; // Moon orbits faster than Earth
                
                // Nested transformation logic for the Moon
                float moonX = pX + moonOrbitRadius * cos(moonAngle);
                float moonY = pY + moonOrbitRadius * sin(moonAngle);
                
                if (showOrbits) {
                    DrawCircleLines((int)pX, (int)pY, moonOrbitRadius, (Color){ 255, 255, 255, 50 });
                }
                DrawCircle((int)moonX, (int)moonY, 3, LIGHTGRAY);
                
                if (showInfo) {
                    DrawText("Moon", (int)moonX + 5, (int)moonY + 5, 10, LIGHTGRAY);
                }
            }

            // Draw Planet Labels next to the planet
            if (showInfo) {
                DrawText(planets[i].name, (int)pX + planets[i].radius + 5, (int)pY + planets[i].radius + 5, 10, RAYWHITE);
            }
        }

        // Draw info panel if toggled
        if (showInfo) {
            drawInformationPanel();
        }

        EndDrawing();
    }

    // De-Initialization
    CloseWindow();
    return 0;
}
