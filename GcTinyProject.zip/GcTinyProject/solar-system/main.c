#include <raylib.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define MAX_STARS 200
#define MAX_ASTEROIDS 250
#define NUM_PLANETS 8
#define NUM_OBJECTS 10 // Sun=0, planets=1..8, moon=9

// Screen dimensions
const int screenWidth = 1200;
const int screenHeight = 800;

// ObjectTransformation Structure (Feature 5)
// Stores object-specific affine transformations.
typedef struct {
    float x;        // Translation X
    float y;        // Translation Y
    float rot;      // Rotation in radians
    float scaleX;   // Scaling X
    float scaleY;   // Scaling Y
    float refX;     // Reflection X (1.0 or -1.0)
    float refY;     // Reflection Y (1.0 or -1.0)
    float shX;      // Shear X
    float shY;      // Shear Y
} ObjectTransform;

// Planet data structure (Feature 8)
typedef struct {
    char name[20];
    char type[30];
    float orbitRadiusX;
    float orbitRadiusY;
    float radius;
    float baseOrbitSpeed;
    float baseRotationSpeed;
    float orbitAngle;
    float rotationAngle;
    int moons;
    char orbitalPeriod[30];
    char rotationPeriod[30];
    char distanceFromSun[40];
    Color color;
} Planet;

// Asteroid Belt (Feature 6)
typedef struct {
    float angle;
    float orbitRadiusX;
    float orbitRadiusY;
    float speed;
    float size;
} Asteroid;

// Comet (Feature 7)
typedef struct {
    float orbitAngle;
    float orbitRadiusX;
    float orbitRadiusY;
    float speed;
    float radius;
    Color color;
} Comet;

// Star structure
typedef struct {
    float x;
    float y;
    float radius;
    float alpha;
} Star;

// Global State
Star stars[MAX_STARS];
Planet planets[NUM_PLANETS];
Asteroid asteroids[MAX_ASTEROIDS];
Comet comet;
ObjectTransform objectObjectTransforms[NUM_OBJECTS];

// View & Camera State (Features 1 & 2)
float fitScale = 1.0f;
float userZoom = 1.0f;
float finalScale = 1.0f;
float cameraX = 0.0f;
float cameraY = 0.0f;

// Simulation State
float simulationSpeed = 1.0f;
bool paused = false;
bool showGrid = true;
bool showAsteroids = true;
bool showComet = false;
bool showInfo = false;
bool ellipticalOrbits = false;
bool selfRotationEnabled = true;
bool transformationMode = false;
int selectedObjectIndex = 3; // Defaults to Earth (Index 3)
bool showDebug = false;
bool fitFullScene = false;

// Resets a transformation matrix back to identity values
void resetObjectTransform(ObjectTransform *t) {
    t->x = 0; t->y = 0;
    t->rot = 0;
    t->scaleX = 1; t->scaleY = 1;
    t->refX = 1; t->refY = 1;
    t->shX = 0; t->shY = 0;
}

// Convert World Coordinates to Screen Coordinates
// Concept: Translation (camera) and Scaling (zoom)
void worldToScreen(float wx, float wy, float *sx, float *sy) {
    float cw = GetScreenWidth() / 2.0f;
    float ch = GetScreenHeight() / 2.0f;
    *sx = cw + (wx - cameraX) * finalScale;
    *sy = ch + (wy - cameraY) * finalScale;
}

void fitSolarSystemToView() {
    float maxWorldRadius = 0.0f;
    
    // Find outermost planet
    for (int i = 0; i < NUM_PLANETS; i++) {
        float ry = ellipticalOrbits ? planets[i].orbitRadiusY : planets[i].orbitRadiusX;
        float r = planets[i].orbitRadiusX > ry ? planets[i].orbitRadiusX : ry;
        if (r > maxWorldRadius) maxWorldRadius = r;
    }
    
    // Account for planet radius padding
    maxWorldRadius += 20.0f; 
    
    // Fit comet if full scene is requested
    if (fitFullScene && showComet) {
        float cometMax = comet.orbitRadiusX > comet.orbitRadiusY ? comet.orbitRadiusX : comet.orbitRadiusY;
        if (cometMax > maxWorldRadius) maxWorldRadius = cometMax;
    }
    
    float padding = 80.0f;
    float usableWidth = GetScreenWidth() - padding * 2.0f;
    float usableHeight = GetScreenHeight() - padding * 2.0f;
    
    if (usableWidth < 10) usableWidth = 10;
    if (usableHeight < 10) usableHeight = 10;
    
    float scaleX = usableWidth / (2.0f * maxWorldRadius);
    float scaleY = usableHeight / (2.0f * maxWorldRadius);
    
    fitScale = scaleX < scaleY ? scaleX : scaleY;
    userZoom = 1.0f;
    finalScale = fitScale * userZoom;
    
    cameraX = 0.0f;
    cameraY = 0.0f;
}

// Apply Object-level transformation matrix equivalents
void applyObjectTransform(float *lx, float *ly, ObjectTransform t) {
    float x = *lx;
    float y = *ly;
    
    // 1. Scale & Reflect
    x *= (t.scaleX * t.refX);
    y *= (t.scaleY * t.refY);
    
    // 2. Shear
    float nx = x + t.shX * y;
    float ny = y + t.shY * x;
    x = nx; y = ny;
    
    // 3. Rotate
    float rx = x * cosf(t.rot) - y * sinf(t.rot);
    float ry = x * sinf(t.rot) + y * cosf(t.rot);
    x = rx; y = ry;
    
    // 4. Translate
    x += t.x;
    y += t.y;
    
    *lx = x;
    *ly = y;
}

void initializeSimulation() {
    // Mercury
    Planet p0 = {"Mercury", "Terrestrial", 80, 100, 5, 0.040f, 0.1f, 0, 0, 0, "88 days", "58 days", "57.9M km", GRAY};
    planets[0] = p0;

    // Venus
    Planet p1 = {"Venus", "Terrestrial", 120, 140, 7, 0.030f, -0.05f, 0, 0, 0, "225 days", "243 days", "108.2M km", (Color){ 255, 255, 150, 255 }};
    planets[1] = p1;

    // Earth
    Planet p2 = {"Earth", "Terrestrial", 165, 185, 8, 0.025f, 0.2f, 0, 0, 1, "365 days", "24 hours", "149.6M km", (Color){ 50, 150, 255, 255 }};
    planets[2] = p2;

    // Mars
    Planet p3 = {"Mars", "Terrestrial", 210, 240, 6, 0.020f, 0.19f, 0, 0, 2, "687 days", "24.6 hours", "227.9M km", RED};
    planets[3] = p3;

    // Jupiter
    Planet p4 = {"Jupiter", "Gas Giant", 290, 320, 16, 0.012f, 0.4f, 0, 0, 79, "12 years", "10 hours", "778.5M km", ORANGE};
    planets[4] = p4;

    // Saturn
    Planet p5 = {"Saturn", "Gas Giant", 380, 420, 14, 0.009f, 0.38f, 0, 0, 82, "29 years", "10.7 hours", "1.4B km", (Color){ 230, 230, 150, 255 }};
    planets[5] = p5;

    // Uranus
    Planet p6 = {"Uranus", "Ice Giant", 470, 520, 11, 0.006f, -0.25f, 0, 0, 27, "84 years", "17 hours", "2.8B km", SKYBLUE};
    planets[6] = p6;

    // Neptune
    Planet p7 = {"Neptune", "Ice Giant", 550, 600, 10, 0.004f, 0.26f, 0, 0, 14, "165 years", "16 hours", "4.5B km", BLUE};
    planets[7] = p7;
    
    // Init Asteroids between Mars and Jupiter
    for (int i=0; i<MAX_ASTEROIDS; i++) {
        asteroids[i].angle = (float)GetRandomValue(0, 360) * PI / 180.0f;
        float rOffset = (float)GetRandomValue(0, 40);
        asteroids[i].orbitRadiusX = 240 + rOffset;
        asteroids[i].orbitRadiusY = 270 + rOffset;
        asteroids[i].speed = (float)GetRandomValue(10, 20) / 1000.0f;
        asteroids[i].size = (float)GetRandomValue(1, 2);
    }
    
    // Init Comet
    comet.orbitAngle = 0.0f;
    comet.orbitRadiusX = 650.0f;
    comet.orbitRadiusY = 200.0f;
    comet.speed = 0.015f;
    comet.radius = 4.0f;
    comet.color = (Color){200, 255, 255, 255};
    
    // Init Stars
    for (int i = 0; i < MAX_STARS; i++) {
        stars[i].x = (float)(GetRandomValue(-2000, 3000));
        stars[i].y = (float)(GetRandomValue(-2000, 3000));
        stars[i].radius = (float)(GetRandomValue(1, 2));
        stars[i].alpha = (float)(GetRandomValue(50, 255)) / 255.0f;
    }
    
    // Init ObjectTransforms
    for (int i=0; i<NUM_OBJECTS; i++) {
        resetObjectTransform(&objectObjectTransforms[i]);
    }
}

void resetSimulation() {
    for (int i = 0; i < NUM_PLANETS; i++) {
        planets[i].orbitAngle = 0.0f;
        planets[i].rotationAngle = 0.0f;
    }
    for(int i=0; i<MAX_ASTEROIDS; i++) {
        asteroids[i].angle = (float)GetRandomValue(0, 360) * PI / 180.0f;
    }
    comet.orbitAngle = 0;
    simulationSpeed = 1.0f;
    ellipticalOrbits = false;
    for (int i=0; i<NUM_OBJECTS; i++) {
        resetObjectTransform(&objectObjectTransforms[i]);
    }
}

void handleInput() {
    // Universal Toggles
    if (IsKeyPressed(KEY_SPACE)) paused = !paused;
    if (IsKeyPressed(KEY_O)) ellipticalOrbits = false;
    if (IsKeyPressed(KEY_E)) ellipticalOrbits = true;
    if (IsKeyPressed(KEY_G)) showGrid = !showGrid;
    if (IsKeyPressed(KEY_T)) transformationMode = !transformationMode;
    if (IsKeyPressed(KEY_B)) showAsteroids = !showAsteroids;
    if (IsKeyPressed(KEY_K)) showComet = !showComet;
    if (IsKeyPressed(KEY_I)) showInfo = !showInfo;
    if (IsKeyPressed(KEY_R)) resetSimulation();
    if (IsKeyPressed(KEY_L)) selfRotationEnabled = !selfRotationEnabled;
    if (IsKeyPressed(KEY_C)) { cameraX = 0; cameraY = 0; }
    if (IsKeyPressed(KEY_ZERO)) { userZoom = 1.0f; finalScale = fitScale * userZoom; }
    if (IsKeyPressed(KEY_F)) {
        if (IsKeyDown(KEY_LEFT_SHIFT) || IsKeyDown(KEY_RIGHT_SHIFT)) {
            fitFullScene = true;
        } else {
            fitFullScene = false;
        }
        fitSolarSystemToView();
    }
    if (IsKeyPressed(KEY_D)) showDebug = !showDebug;
    
    // Speed adjustments
    if (IsKeyDown(KEY_EQUAL) || IsKeyDown(KEY_KP_ADD)) simulationSpeed += 0.05f;
    if (IsKeyDown(KEY_MINUS) || IsKeyDown(KEY_KP_SUBTRACT)) {
        simulationSpeed -= 0.05f;
        if(simulationSpeed < 0) simulationSpeed = 0;
    }
    
    // Zoom adjustments
    if (IsKeyDown(KEY_RIGHT_BRACKET)) { userZoom += 0.05f; finalScale = fitScale * userZoom; }
    if (IsKeyDown(KEY_LEFT_BRACKET)) {
        userZoom -= 0.05f;
        if (userZoom < 0.1f) userZoom = 0.1f;
        finalScale = fitScale * userZoom;
    }

    // ObjectTransformation Mode Keybindings
    if (transformationMode) {
        if (IsKeyPressed(KEY_ONE)) selectedObjectIndex = 0;   // Sun
        if (IsKeyPressed(KEY_TWO)) selectedObjectIndex = 1;   // Mercury
        if (IsKeyPressed(KEY_THREE)) selectedObjectIndex = 2; // Venus
        if (IsKeyPressed(KEY_FOUR)) selectedObjectIndex = 3;  // Earth
        if (IsKeyPressed(KEY_FIVE)) selectedObjectIndex = 4;  // Mars
        if (IsKeyPressed(KEY_SIX)) selectedObjectIndex = 5;   // Jupiter
        if (IsKeyPressed(KEY_SEVEN)) selectedObjectIndex = 6; // Saturn
        if (IsKeyPressed(KEY_EIGHT)) selectedObjectIndex = 7; // Uranus
        if (IsKeyPressed(KEY_NINE)) selectedObjectIndex = 8;  // Neptune
        if (IsKeyPressed(KEY_M)) selectedObjectIndex = 9;     // Moon
        
        ObjectTransform *t = &objectObjectTransforms[selectedObjectIndex];
        
        // ObjectTransform Operations
        if (IsKeyDown(KEY_UP)) t->y -= 2.0f;
        if (IsKeyDown(KEY_DOWN)) t->y += 2.0f;
        if (IsKeyDown(KEY_LEFT)) t->x -= 2.0f;
        if (IsKeyDown(KEY_RIGHT)) t->x += 2.0f;
        
        if (IsKeyDown(KEY_Q)) t->rot -= 0.05f;
        if (IsKeyDown(KEY_W)) t->rot += 0.05f; // overrides pan up when in transform mode
        if (IsKeyDown(KEY_E)) t->rot += 0.05f; 
        
        if (IsKeyDown(KEY_Z)) { t->scaleX += 0.05f; t->scaleY += 0.05f; }
        if (IsKeyDown(KEY_X)) { t->scaleX -= 0.05f; t->scaleY -= 0.05f; }
        
        if (IsKeyPressed(KEY_Y)) t->refX *= -1.0f;
        if (IsKeyPressed(KEY_H)) t->refY *= -1.0f;
        
        if (IsKeyDown(KEY_U)) t->shX += 0.05f;
        if (IsKeyDown(KEY_J)) t->shY += 0.05f;
        
        if (IsKeyPressed(KEY_BACKSPACE)) resetObjectTransform(t);
    } else {
        // Normal Camera Panning
        float panSpeed = 10.0f;
        if (IsKeyDown(KEY_UP) || IsKeyDown(KEY_W)) cameraY += panSpeed;
        if (IsKeyDown(KEY_DOWN) || IsKeyDown(KEY_S)) cameraY -= panSpeed;
        if (IsKeyDown(KEY_LEFT) || IsKeyDown(KEY_A)) cameraX += panSpeed;
        if (IsKeyDown(KEY_RIGHT) || IsKeyDown(KEY_D)) cameraX -= panSpeed;
    }
}

void updateSimulation() {
    if (paused) return;

    for (int i = 0; i < NUM_PLANETS; i++) {
        planets[i].orbitAngle += planets[i].baseOrbitSpeed * simulationSpeed;
        if (planets[i].orbitAngle > 2 * PI) planets[i].orbitAngle -= 2 * PI;
        
        if (selfRotationEnabled) {
            planets[i].rotationAngle += planets[i].baseRotationSpeed * simulationSpeed;
            if (planets[i].rotationAngle > 2 * PI) planets[i].rotationAngle -= 2 * PI;
        }
    }
    
    for (int i = 0; i < MAX_ASTEROIDS; i++) {
        asteroids[i].angle += asteroids[i].speed * simulationSpeed;
        if (asteroids[i].angle > 2 * PI) asteroids[i].angle -= 2 * PI;
    }
    
    comet.orbitAngle += comet.speed * simulationSpeed;
    if (comet.orbitAngle > 2 * PI) comet.orbitAngle -= 2 * PI;
}

void drawStars() {
    for (int i = 0; i < MAX_STARS; i++) {
        Color starColor = WHITE;
        starColor.a = (unsigned char)(stars[i].alpha * 255);
        float sx, sy;
        worldToScreen(stars[i].x, stars[i].y, &sx, &sy);
        float r = stars[i].radius * finalScale;
        if (r < 1.0f) r = 1.0f;
        DrawCircle((int)sx, (int)sy, r, starColor);
    }
}

void drawCoordinateGrid() {
    // Draw grid lines responding to zoom and pan
    for (int i = -2000; i <= 2000; i += 100) {
        float sx1, sy1, sx2, sy2;
        worldToScreen(i, -2000, &sx1, &sy1);
        worldToScreen(i, 2000, &sx2, &sy2);
        Color c = (i == 0) ? (Color){255,255,255,100} : (Color){255,255,255,20};
        DrawLine((int)sx1, (int)sy1, (int)sx2, (int)sy2, c);
        
        worldToScreen(-2000, i, &sx1, &sy1);
        worldToScreen(2000, i, &sx2, &sy2);
        DrawLine((int)sx1, (int)sy1, (int)sx2, (int)sy2, c);
    }
    // Origin Label
    float ox, oy;
    worldToScreen(0, 0, &ox, &oy);
    DrawText("(0, 0)", (int)ox + 5, (int)oy + 5, 10, WHITE);
    
    worldToScreen(2000, 0, &ox, &oy);
    DrawText("+X", (int)ox - 20, (int)oy + 5, 10, WHITE);
    
    worldToScreen(0, 2000, &ox, &oy);
    DrawText("+Y", (int)ox + 5, (int)oy - 20, 10, WHITE);
}

void drawWorldCircleLines(float worldX, float worldY, float radiusX, float radiusY, Color color) {
    int numPts = 64;
    Vector2 pts[64];
    for (int i=0; i<numPts; i++) {
        float a = (float)i / numPts * 2 * PI;
        float wx = worldX + radiusX * cosf(a);
        float wy = worldY + radiusY * sinf(a);
        float sx, sy;
        worldToScreen(wx, wy, &sx, &sy);
        pts[i] = (Vector2){sx, sy};
    }
    for (int i=0; i<numPts; i++) {
        DrawLineEx(pts[i], pts[(i+1)%numPts], 1.0f, color);
    }
}

void drawObjectTransformedCircle(float worldX, float worldY, float radius, Color color, ObjectTransform t, float selfRotAngle, bool isSelected) {
    int numPts = 32;
    Vector2 pts[32];
    
    float minVisualPixelRadius = 3.0f;
    float visualRadius = radius;
    if (visualRadius * finalScale < minVisualPixelRadius) {
        visualRadius = minVisualPixelRadius / finalScale;
    }
    
    // Generate transformed vertices
    for(int i=0; i<numPts; i++) {
        float a = (float)i / numPts * 2 * PI;
        float lx = visualRadius * cosf(a);
        float ly = visualRadius * sinf(a);
        
        applyObjectTransform(&lx, &ly, t);
        
        float sx, sy;
        worldToScreen(worldX + lx, worldY + ly, &sx, &sy);
        pts[i] = (Vector2){sx, sy};
    }
    
    float cx = 0, cy = 0;
    applyObjectTransform(&cx, &cy, t);
    float scx, scy;
    worldToScreen(worldX + cx, worldY + cy, &scx, &scy);
    
    // Fill circle via triangles
    for(int i=0; i<numPts; i++) {
        DrawTriangle(pts[(i+1)%numPts], pts[i], (Vector2){scx, scy}, color);
        DrawTriangle(pts[i], pts[(i+1)%numPts], (Vector2){scx, scy}, color);
    }
    
    // Rotation Marker (Feature 3)
    float mx = visualRadius * cosf(selfRotAngle);
    float my = visualRadius * sinf(selfRotAngle);
    applyObjectTransform(&mx, &my, t);
    float smx, smy;
    worldToScreen(worldX + mx, worldY + my, &smx, &smy);
    DrawLineEx((Vector2){scx, scy}, (Vector2){smx, smy}, 2.0f, WHITE);
    
    // Bounding Box (Feature 5)
    if(isSelected) {
        float r2 = visualRadius * 1.5f;
        Vector2 box[4] = {
            {-r2, -r2}, {r2, -r2}, {r2, r2}, {-r2, r2}
        };
        for(int i=0; i<4; i++) {
            applyObjectTransform(&box[i].x, &box[i].y, t);
            worldToScreen(worldX + box[i].x, worldY + box[i].y, &box[i].x, &box[i].y);
        }
        for(int i=0; i<4; i++) {
            DrawLineEx(box[i], box[(i+1)%4], 1.0f, YELLOW);
        }
    }
}

void drawAsteroids() {
    if (!showAsteroids) return;
    for (int i=0; i<MAX_ASTEROIDS; i++) {
        float ax = asteroids[i].orbitRadiusX * cosf(asteroids[i].angle);
        float ay = (ellipticalOrbits ? asteroids[i].orbitRadiusY : asteroids[i].orbitRadiusX) * sinf(asteroids[i].angle);
        
        float sx, sy;
        worldToScreen(ax, ay, &sx, &sy);
        float r = asteroids[i].size * finalScale;
        if (r < 1.0f) r = 1.0f;
        DrawCircle((int)sx, (int)sy, r, GRAY);
    }
}

void drawComet() {
    if (!showComet) return;
    float cx = comet.orbitRadiusX * cosf(comet.orbitAngle);
    float cy = comet.orbitRadiusY * sinf(comet.orbitAngle);
    
    float scx, scy;
    worldToScreen(cx, cy, &scx, &scy);
    
    // Comet tail
    for(int i=1; i<=15; i++) {
        float pastAngle = comet.orbitAngle - (i * 0.015f);
        float tcx = comet.orbitRadiusX * cosf(pastAngle);
        float tcy = comet.orbitRadiusY * sinf(pastAngle);
        float stcx, stcy;
        worldToScreen(tcx, tcy, &stcx, &stcy);
        float r = comet.radius * finalScale * (1.0f - (i/15.0f));
        if (r < 0.5f) r = 0.5f;
        DrawCircle((int)stcx, (int)stcy, r, (Color){200, 255, 255, (unsigned char)(255 - i*15)});
    }
    
    // Comet head
    float hr = comet.radius * finalScale;
    if (hr < 2.0f) hr = 2.0f;
    DrawCircle((int)scx, (int)scy, hr, comet.color);
}

void drawUI() {
    int sWidth = GetScreenWidth();
    int sHeight = GetScreenHeight();
    DrawText("2D SOLAR SYSTEM SIMULATION", sWidth / 2 - 150, 10, 20, RAYWHITE);
    
    // Simulation Status
    DrawRectangle(10, sHeight - 180, 220, 170, (Color){0,0,0,200});
    DrawRectangleLines(10, sHeight - 180, 220, 170, WHITE);
    DrawText("Simulation Status", 20, sHeight - 170, 10, YELLOW);
    DrawText(TextFormat("Speed: %.2fx", simulationSpeed), 20, sHeight - 150, 10, WHITE);
    DrawText(TextFormat("View: %s", (userZoom == 1.0f && cameraX == 0 && cameraY == 0) ? "FIT" : "MANUAL"), 20, sHeight - 135, 10, WHITE);
    DrawText(TextFormat("Zoom: %.0f%%", userZoom * 100), 20, sHeight - 120, 10, WHITE);
    DrawText(TextFormat("Orbit: %s", ellipticalOrbits ? "ELLIPTICAL" : "CIRCULAR"), 20, sHeight - 105, 10, WHITE);
    DrawText(TextFormat("Grid: %s", showGrid ? "ON" : "OFF"), 20, sHeight - 90, 10, WHITE);
    DrawText(TextFormat("Asteroids: %s", showAsteroids ? "ON" : "OFF"), 20, sHeight - 75, 10, WHITE);
    DrawText(TextFormat("Comet: %s", showComet ? "ON" : "OFF"), 20, sHeight - 60, 10, WHITE);
    DrawText(TextFormat("Self Rotation: %s", selfRotationEnabled ? "ON" : "OFF"), 20, sHeight - 45, 10, WHITE);
    if(paused) DrawText("PAUSED", 20, sHeight - 25, 10, RED);
    
    // ObjectTransformation Panel
    if (transformationMode) {
        DrawRectangle(sWidth - 230, 10, 220, 250, (Color){0,0,0,200});
        DrawRectangleLines(sWidth - 230, 10, 220, 250, YELLOW);
        DrawText("TRANSFORMATION MODE", sWidth - 220, 20, 10, YELLOW);
        
        char* objName = "Sun";
        if(selectedObjectIndex > 0 && selectedObjectIndex < 9) objName = planets[selectedObjectIndex-1].name;
        if(selectedObjectIndex == 9) objName = "Moon";
        
        DrawText(TextFormat("Selected: %s (Key %d)", objName, selectedObjectIndex==9?0:selectedObjectIndex+1), sWidth - 220, 40, 10, WHITE);
        
        ObjectTransform t = objectObjectTransforms[selectedObjectIndex];
        DrawText("Translation (Arrows)", sWidth - 220, 60, 10, LIGHTGRAY);
        DrawText(TextFormat("X: %.1f  Y: %.1f", t.x, t.y), sWidth - 210, 75, 10, WHITE);
        
        DrawText("Rotation (Q/E)", sWidth - 220, 95, 10, LIGHTGRAY);
        DrawText(TextFormat("%.1f deg", t.rot * 180.0f / PI), sWidth - 210, 110, 10, WHITE);
        
        DrawText("Scale (Z/X)", sWidth - 220, 130, 10, LIGHTGRAY);
        DrawText(TextFormat("X: %.2f  Y: %.2f", t.scaleX, t.scaleY), sWidth - 210, 145, 10, WHITE);

        DrawText("Reflection (Y/H)", sWidth - 220, 165, 10, LIGHTGRAY);
        DrawText(TextFormat("X: %.1f  Y: %.1f", t.refX, t.refY), sWidth - 210, 180, 10, WHITE);

        DrawText("Shear (U/J)", sWidth - 220, 200, 10, LIGHTGRAY);
        DrawText(TextFormat("X: %.2f  Y: %.2f", t.shX, t.shY), sWidth - 210, 215, 10, WHITE);
        
        DrawText("[BACKSPACE] Reset", sWidth - 220, 235, 10, GRAY);
    }
    
    // Controls Help Panel
    DrawRectangle(10, 10, 230, 295, (Color){0,0,0,150});
    DrawText("CONTROLS", 20, 20, 10, YELLOW);
    DrawText("SPACE   Pause / Resume", 20, 40, 10, WHITE);
    DrawText("+ / -   Simulation Speed", 20, 55, 10, WHITE);
    DrawText("[ / ]   Zoom In/Out", 20, 70, 10, WHITE);
    DrawText("0       Reset Zoom", 20, 85, 10, WHITE);
    DrawText("F       Fit To View", 20, 100, 10, WHITE);
    DrawText("Arrows  Pan Camera", 20, 115, 10, WHITE);
    DrawText("C       Reset Camera", 20, 130, 10, WHITE);
    DrawText("G       Grid", 20, 145, 10, WHITE);
    DrawText("T       Transform Mode", 20, 160, 10, WHITE);
    DrawText("B       Asteroid Belt", 20, 175, 10, WHITE);
    DrawText("K       Comet", 20, 190, 10, WHITE);
    DrawText("E       Elliptical Orbits", 20, 205, 10, WHITE);
    DrawText("O       Circular Orbits", 20, 220, 10, WHITE);
    DrawText("I       Planet Info", 20, 235, 10, WHITE);
    DrawText("L       Toggle Self-Rotation", 20, 250, 10, WHITE);
    DrawText("R       Reset Simulation", 20, 265, 10, WHITE);
    DrawText("ESC     Exit", 20, 280, 10, WHITE);

    // Planet Information (Feature 8)
    if (showInfo && selectedObjectIndex > 0 && selectedObjectIndex < 9) {
        Planet p = planets[selectedObjectIndex-1];
        DrawRectangle(sWidth - 230, sHeight - 250, 220, 240, (Color){0,0,0,200});
        DrawRectangleLines(sWidth - 230, sHeight - 250, 220, 240, GREEN);
        
        int px = sWidth - 220;
        int py = sHeight - 240;
        DrawText(p.name, px, py, 20, p.color); py += 30;
        DrawText(TextFormat("Type: %s", p.type), px, py, 10, WHITE); py += 20;
        DrawText(TextFormat("Distance: %s", p.distanceFromSun), px, py, 10, WHITE); py += 20;
        DrawText(TextFormat("Moons: %d", p.moons), px, py, 10, WHITE); py += 20;
        DrawText(TextFormat("Orb. Period: %s", p.orbitalPeriod), px, py, 10, WHITE); py += 20;
        DrawText(TextFormat("Rot. Period: %s", p.rotationPeriod), px, py, 10, WHITE); py += 20;
        
        DrawText("Live Data:", px, py, 10, GRAY); py += 15;
        DrawText(TextFormat("Orbit Angle: %.2f rad", p.orbitAngle), px, py, 10, WHITE); py += 15;
        DrawText(TextFormat("Rot Angle: %.2f rad", p.rotationAngle), px, py, 10, WHITE);
    }
}

int main(void) {
    SetConfigFlags(FLAG_WINDOW_RESIZABLE);
    InitWindow(screenWidth, screenHeight, "2D SOLAR SYSTEM SIMULATION");
    SetTargetFPS(60);

    initializeSimulation();
    fitSolarSystemToView();

    // Animation Loop
    while (!WindowShouldClose()) {
        if (IsWindowResized()) {
            fitSolarSystemToView();
        }
        
        handleInput();
        updateSimulation();

        BeginDrawing();
        ClearBackground(BLACK);

        drawStars();
        if(showGrid) drawCoordinateGrid();
        
        // Orbital Paths
        for (int i = 0; i < NUM_PLANETS; i++) {
            float ry = ellipticalOrbits ? planets[i].orbitRadiusY : planets[i].orbitRadiusX;
            drawWorldCircleLines(0, 0, planets[i].orbitRadiusX, ry, (Color){255,255,255,30});
        }
        
        drawAsteroids();
        drawComet();
        
        // Sun
        bool sunSel = (transformationMode && selectedObjectIndex == 0);
        drawObjectTransformedCircle(0, 0, 45, YELLOW, objectObjectTransforms[0], 0, sunSel);
        
        // Planets
        for (int i = 0; i < NUM_PLANETS; i++) {
            float px = planets[i].orbitRadiusX * cosf(planets[i].orbitAngle);
            float py = (ellipticalOrbits ? planets[i].orbitRadiusY : planets[i].orbitRadiusX) * sinf(planets[i].orbitAngle);
            
            bool isSelected = (transformationMode && selectedObjectIndex == i + 1);
            drawObjectTransformedCircle(px, py, planets[i].radius, planets[i].color, objectObjectTransforms[i + 1], planets[i].rotationAngle, isSelected);
            
            // Earth's Moon (Hierarchical transformation)
            if (i == 2) { 
                float moonDistX = 20.0f;
                float moonDistY = ellipticalOrbits ? 25.0f : 20.0f;
                float moonAngle = planets[i].orbitAngle * 4.0f; 
                
                // Moon relative to Earth
                float mx = px + moonDistX * cosf(moonAngle);
                float my = py + moonDistY * sinf(moonAngle);
                
                drawWorldCircleLines(px, py, moonDistX, moonDistY, (Color){255,255,255,50});
                
                bool moonSel = (transformationMode && selectedObjectIndex == 9);
                drawObjectTransformedCircle(mx, my, 3.0f, LIGHTGRAY, objectObjectTransforms[9], moonAngle * 2, moonSel);
            }
        }
        
        drawUI();
        
        if (showDebug) {
            int sWidth = GetScreenWidth();
            DrawRectangle(sWidth/2 - 100, 50, 200, 130, (Color){0,0,0,200});
            DrawText("DEBUG INFO", sWidth/2 - 80, 60, 10, RED);
            DrawText(TextFormat("Window: %d x %d", GetScreenWidth(), GetScreenHeight()), sWidth/2 - 90, 80, 10, WHITE);
            DrawText(TextFormat("Fit scale: %.4f", fitScale), sWidth/2 - 90, 95, 10, WHITE);
            DrawText(TextFormat("User zoom: %.2f", userZoom), sWidth/2 - 90, 110, 10, WHITE);
            DrawText(TextFormat("Final scale: %.4f", finalScale), sWidth/2 - 90, 125, 10, WHITE);
            DrawText(TextFormat("Camera: %.1f, %.1f", cameraX, cameraY), sWidth/2 - 90, 140, 10, WHITE);
            DrawText(TextFormat("Fit Full Scene: %s", fitFullScene?"YES":"NO"), sWidth/2 - 90, 155, 10, WHITE);
        }
        
        EndDrawing();
    }

    CloseWindow();
    return 0;
}
