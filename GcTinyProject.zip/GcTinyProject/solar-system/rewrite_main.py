import re

with open("main.c", "r") as f:
    code = f.read()

# Add debug state
code = code.replace("bool showInfo = false;", "bool showInfo = false;\nbool showDebug = false;")

# Replace View & Camera State
view_state_old = """// View & Camera State (Features 1 & 2)
float zoom = 1.0f;
float cameraX = 0.0f;
float cameraY = 0.0f;
float centerX = 600.0f;
float centerY = 400.0f;"""
view_state_new = """// View & Camera State (Features 1 & 2)
float fitScale = 1.0f;
float userZoom = 1.0f;
float cameraX = 0.0f;
float cameraY = 0.0f;
float centerX = 600.0f;
float centerY = 400.0f;"""
code = code.replace(view_state_old, view_state_new)

world_to_screen_old = """void worldToScreen(float wx, float wy, float *sx, float *sy) {
    *sx = centerX + (wx - centerX) * zoom + cameraX;
    *sy = centerY + (wy - centerY) * zoom + cameraY;
}"""
world_to_screen_new = """void worldToScreen(float wx, float wy, float *sx, float *sy) {
    float finalScale = fitScale * userZoom;
    *sx = centerX + (wx - cameraX) * finalScale;
    *sy = centerY + (wy - cameraY) * finalScale;
}

void fitSolarSystemToView(bool fullScene) {
    int w = GetScreenWidth();
    int h = GetScreenHeight();
    centerX = w / 2.0f;
    centerY = h / 2.0f;
    
    float padding = 80.0f;
    float usableW = w - padding * 2;
    float usableH = h - padding * 2;
    
    float maxR = 600.0f; // Neptune
    if (showAsteroids && maxR < 310.0f) maxR = 310.0f;
    if (fullScene && showComet) maxR = fmax(maxR, 650.0f); // Comet max radius
    
    maxR += 20.0f; // safety margin for planet sizes
    
    float scaleX = usableW / (2.0f * maxR);
    float scaleY = usableH / (2.0f * maxR);
    fitScale = fmin(scaleX, scaleY);
    
    userZoom = 1.0f;
    cameraX = 0;
    cameraY = 0;
}"""
code = code.replace(world_to_screen_old, world_to_screen_new)

# Update handleInput
zoom_keys_old = """    if (IsKeyPressed(KEY_ZERO)) zoom = 1.0f;
    
    // Speed adjustments
    if (IsKeyDown(KEY_EQUAL) || IsKeyDown(KEY_KP_ADD)) simulationSpeed += 0.05f;
    if (IsKeyDown(KEY_MINUS) || IsKeyDown(KEY_KP_SUBTRACT)) {
        simulationSpeed -= 0.05f;
        if(simulationSpeed < 0) simulationSpeed = 0;
    }
    
    // Zoom adjustments
    if (IsKeyDown(KEY_RIGHT_BRACKET)) zoom += 0.05f;
    if (IsKeyDown(KEY_LEFT_BRACKET)) {
        zoom -= 0.05f;
        if(zoom < 0.2f) zoom = 0.2f; // Min zoom 20%
    }
    if(zoom > 2.5f) zoom = 2.5f; // Max zoom 250%"""
zoom_keys_new = """    if (IsKeyPressed(KEY_ZERO)) userZoom = 1.0f;
    
    // Speed adjustments
    if (IsKeyDown(KEY_EQUAL) || IsKeyDown(KEY_KP_ADD)) simulationSpeed += 0.05f;
    if (IsKeyDown(KEY_MINUS) || IsKeyDown(KEY_KP_SUBTRACT)) {
        simulationSpeed -= 0.05f;
        if(simulationSpeed < 0) simulationSpeed = 0;
    }
    
    // Zoom adjustments
    if (IsKeyDown(KEY_RIGHT_BRACKET)) userZoom += 0.05f;
    if (IsKeyDown(KEY_LEFT_BRACKET)) {
        userZoom -= 0.05f;
        if(userZoom < 0.2f) userZoom = 0.2f; // Min zoom 20%
    }
    if(userZoom > 5.0f) userZoom = 5.0f; // Max zoom 500%
    
    if (IsKeyPressed(KEY_F)) {
        fitSolarSystemToView(IsKeyDown(KEY_LEFT_SHIFT) || IsKeyDown(KEY_RIGHT_SHIFT));
    }
    if (IsKeyPressed(KEY_D)) showDebug = !showDebug;"""
code = code.replace(zoom_keys_old, zoom_keys_new)

camera_pan_old = """        // Normal Camera Panning
        float panSpeed = 10.0f;
        if (IsKeyDown(KEY_UP) || IsKeyDown(KEY_W)) cameraY += panSpeed;
        if (IsKeyDown(KEY_DOWN) || IsKeyDown(KEY_S)) cameraY -= panSpeed;
        if (IsKeyDown(KEY_LEFT) || IsKeyDown(KEY_A)) cameraX += panSpeed;
        if (IsKeyDown(KEY_RIGHT) || IsKeyDown(KEY_D)) cameraX -= panSpeed;"""
camera_pan_new = """        // Normal Camera Panning
        float panSpeed = 10.0f / (fitScale * userZoom);
        if (IsKeyDown(KEY_UP) || IsKeyDown(KEY_W)) cameraY -= panSpeed;
        if (IsKeyDown(KEY_DOWN) || IsKeyDown(KEY_S)) cameraY += panSpeed;
        if (IsKeyDown(KEY_LEFT) || IsKeyDown(KEY_A)) cameraX -= panSpeed;
        if (IsKeyDown(KEY_RIGHT) || IsKeyDown(KEY_D)) cameraX += panSpeed;"""
code = code.replace(camera_pan_old, camera_pan_new)

# Modify sizes
code = code.replace("stars[i].radius * zoom", "stars[i].radius")
code = code.replace("asteroids[i].size * zoom", "fmax(asteroids[i].size * fitScale * userZoom, 1.0f)")
code = code.replace("comet.radius * zoom", "fmax(comet.radius * fitScale * userZoom, 1.0f)")
code = code.replace("comet.radius * zoom * (1.0f - (i/15.0f))", "fmax(comet.radius * fitScale * userZoom * (1.0f - (i/15.0f)), 1.0f)")


# Modify drawTransformedCircle to apply minimum pixel radius
dtc_old = """void drawTransformedCircle(float worldX, float worldY, float radius, Color color, ObjectTransform t, float selfRotAngle, bool isSelected) {
    int numPts = 32;
    Vector2 pts[32];
    
    // Generate transformed vertices
    for(int i=0; i<numPts; i++) {
        float a = (float)i / numPts * 2 * PI;
        float lx = radius * cosf(a);
        float ly = radius * sinf(a);"""
dtc_new = """void drawTransformedCircle(float worldX, float worldY, float baseRadius, Color color, ObjectTransform t, float selfRotAngle, bool isSelected) {
    int numPts = 32;
    Vector2 pts[32];
    
    float finalScale = fitScale * userZoom;
    float minWorldRadius = 2.0f / finalScale;
    float radius = fmax(baseRadius, minWorldRadius);
    
    // Generate transformed vertices
    for(int i=0; i<numPts; i++) {
        float a = (float)i / numPts * 2 * PI;
        float lx = radius * cosf(a);
        float ly = radius * sinf(a);"""
code = code.replace(dtc_old, dtc_new)

# Add Debug UI and resize handler to Main loop
main_loop_old = """int main(void) {
    InitWindow(screenWidth, screenHeight, "2D SOLAR SYSTEM SIMULATION");
    SetTargetFPS(60);

    initializeSimulation();

    // Animation Loop
    while (!WindowShouldClose()) {"""
main_loop_new = """int main(void) {
    SetConfigFlags(FLAG_WINDOW_RESIZABLE);
    InitWindow(screenWidth, screenHeight, "2D SOLAR SYSTEM SIMULATION");
    SetTargetFPS(60);

    initializeSimulation();
    fitSolarSystemToView(false);

    // Animation Loop
    while (!WindowShouldClose()) {
        if (IsWindowResized()) {
            fitSolarSystemToView(false);
        }"""
code = code.replace(main_loop_old, main_loop_new)

# UI additions
ui_status_old = """    DrawText("Simulation Status", 20, screenHeight - 150, 10, YELLOW);
    DrawText(TextFormat("Speed: %.2fx", simulationSpeed), 20, screenHeight - 130, 10, WHITE);
    DrawText(TextFormat("Zoom: %.0f%%", zoom * 100), 20, screenHeight - 115, 10, WHITE);"""
ui_status_new = """    DrawText("Simulation Status", 20, screenHeight - 150, 10, YELLOW);
    DrawText(TextFormat("Speed: %.2fx", simulationSpeed), 20, screenHeight - 130, 10, WHITE);
    DrawText(TextFormat("Zoom: %.0f%% (User: %.0f%%)", fitScale * userZoom * 100, userZoom * 100), 20, screenHeight - 115, 10, WHITE);"""
code = code.replace(ui_status_old, ui_status_new)

controls_old = """    DrawText("CONTROLS", 20, 20, 10, YELLOW);
    DrawText("SPACE   Pause / Resume", 20, 40, 10, WHITE);
    DrawText("+ / -   Simulation Speed", 20, 55, 10, WHITE);
    DrawText("[ / ]   Zoom In/Out", 20, 70, 10, WHITE);
    DrawText("0       Reset Zoom", 20, 85, 10, WHITE);
    DrawText("Arrows  Pan Camera", 20, 100, 10, WHITE);
    DrawText("C       Reset Camera", 20, 115, 10, WHITE);
    DrawText("G       Grid", 20, 130, 10, WHITE);"""
controls_new = """    DrawText("CONTROLS", 20, 20, 10, YELLOW);
    DrawText("SPACE   Pause / Resume", 20, 40, 10, WHITE);
    DrawText("+ / -   Simulation Speed", 20, 55, 10, WHITE);
    DrawText("[ / ]   Zoom In/Out", 20, 70, 10, WHITE);
    DrawText("0       Reset Zoom", 20, 85, 10, WHITE);
    DrawText("Arrows  Pan Camera", 20, 100, 10, WHITE);
    DrawText("C       Reset Camera", 20, 115, 10, WHITE);
    DrawText("F       Fit To View", 20, 130, 10, GREEN);
    DrawText("G       Grid", 20, 145, 10, WHITE);"""
code = code.replace(controls_old, controls_new)

code = code.replace('DrawText("T       Transformation Mode", 20, 145, 10, WHITE);', 'DrawText("T       Transformation Mode", 20, 160, 10, WHITE);')
code = code.replace('DrawText("B       Asteroid Belt", 20, 160, 10, WHITE);', 'DrawText("B       Asteroid Belt", 20, 175, 10, WHITE);')
code = code.replace('DrawText("K       Comet", 20, 175, 10, WHITE);', 'DrawText("K       Comet", 20, 190, 10, WHITE);')
code = code.replace('DrawText("E       Elliptical Orbits", 20, 190, 10, WHITE);', 'DrawText("E       Elliptical Orbits", 20, 205, 10, WHITE);')
code = code.replace('DrawText("O       Circular Orbits", 20, 205, 10, WHITE);', 'DrawText("O       Circular Orbits", 20, 220, 10, WHITE);')
code = code.replace('DrawText("I       Planet Information", 20, 220, 10, WHITE);', 'DrawText("I       Planet Information", 20, 235, 10, WHITE);')
code = code.replace('DrawText("L       Toggle Self-Rotation", 20, 235, 10, WHITE);', 'DrawText("L       Toggle Self-Rotation", 20, 250, 10, WHITE);')
code = code.replace('DrawText("R       Reset Simulation", 20, 250, 10, WHITE);', 'DrawText("R       Reset Simulation", 20, 265, 10, WHITE);')
code = code.replace('DrawText("ESC     Exit", 20, 265, 10, WHITE);', 'DrawText("ESC     Exit", 20, 280, 10, WHITE);')
code = code.replace('DrawRectangle(10, 10, 230, 280, (Color){0,0,0,150});', 'DrawRectangle(10, 10, 230, 300, (Color){0,0,0,150});')

debug_block = """
    if (showDebug) {
        DrawRectangle(screenWidth / 2 - 100, screenHeight - 150, 200, 140, (Color){0,0,0,200});
        DrawRectangleLines(screenWidth / 2 - 100, screenHeight - 150, 200, 140, RED);
        DrawText("DEBUG OVERLAY", screenWidth / 2 - 90, screenHeight - 140, 10, RED);
        DrawText(TextFormat("Window: %d x %d", GetScreenWidth(), GetScreenHeight()), screenWidth / 2 - 90, screenHeight - 120, 10, WHITE);
        DrawText(TextFormat("Fit scale: %.4f", fitScale), screenWidth / 2 - 90, screenHeight - 100, 10, WHITE);
        DrawText(TextFormat("User zoom: %.2f", userZoom), screenWidth / 2 - 90, screenHeight - 85, 10, WHITE);
        DrawText(TextFormat("Final scale: %.4f", fitScale * userZoom), screenWidth / 2 - 90, screenHeight - 70, 10, WHITE);
        DrawText(TextFormat("Camera: X=%.0f Y=%.0f", cameraX, cameraY), screenWidth / 2 - 90, screenHeight - 55, 10, WHITE);
    }
}
"""
code = code.replace("    }\n}", "    }\n" + debug_block)

with open("main.c", "w") as f:
    f.write(code)
